package com.carlitos.Pronacej;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class ResultadosUnoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.resultados_uno);
    }
}
